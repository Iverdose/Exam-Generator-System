﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for iden.xaml
    /// </summary>
    public partial class iden : Window
    {
        

        public iden()
        {
            InitializeComponent();
            
        }

        private void buttond1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login a = new login();
            a.Show();
        }

        private void buttond2(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createacc a = new createacc();
            a.Show();
        }

        private void createexamclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createexam g = new createexam();
            g.Show();
        }

        private void uploadclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            upload d = new upload();
            d.Show();
        }

        private void homeclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Dashboard d = new Dashboard();
            d.Show();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void viewscoresclick(object sender, RoutedEventArgs e)
        {
            
        }

        private void timer_click(object sender, RoutedEventArgs e)
        {
            
        }

        private void flashcard_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            flashcard f = new flashcard();
            f.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            

        }
      

        
    }
}
