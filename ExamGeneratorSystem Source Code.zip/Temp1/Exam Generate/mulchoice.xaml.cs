﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for mulchoice.xaml
    /// </summary>
    public partial class mulchoice : Window
    {
        public mulchoice()
        {
            InitializeComponent();
        }

        private void homeclock(object sender, RoutedEventArgs e)
        {

        }

        private void homeclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Dashboard j = new Dashboard();
            j.Show();
        }

        private void uploadclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            upload h = new upload();
            h.Show();
        }

        private void createexamclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createexam k = new createexam();
            k.Show();
        }

        private void buttond1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login l = new login();
            l.Show();
        }

        private void buttond2(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createacc m = new createacc();
            m.Show();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void flashcard_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            flashcard f = new flashcard();
            f.Show();
        }
    }
}
