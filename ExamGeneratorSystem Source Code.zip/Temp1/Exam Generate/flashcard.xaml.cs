﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for flashcard.xaml
    /// </summary>
    public partial class flashcard : Window
    {
        public flashcard()
        {
            InitializeComponent();
        }

        private void backtodash_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Dashboard s = new Dashboard();
            s.Show();
        }

        private void flashdef_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            flashans s = new flashans();
            s.Show();
        }
    }
}
