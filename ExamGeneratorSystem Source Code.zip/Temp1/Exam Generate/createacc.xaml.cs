﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for createacc.xaml
    /// </summary>
    public partial class createacc : Window
    {
        public createacc()
        {
            InitializeComponent();
        }

        private void button(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login f2 = new login();
            f2.Show();
        }

        private void register_click(object sender, RoutedEventArgs e)
        {
           try
            {
                SqlConnection con = new SqlConnection(@"Server=KUUHAKU;Database=ExamGenerator_DB;Integrated Security=True");
                con.Open();
                string add_data = "INSERT INTO [dbo].[StudentTB] VALUES(@StudentName,@StudentPassword)";
                SqlCommand cmd = new SqlCommand(add_data, con);

                cmd.Parameters.AddWithValue("@StudentName", username.Text);
                cmd.Parameters.AddWithValue("@Password", password.Password);
                cmd.ExecuteNonQuery();
                con.Close();

                username.Text = "";
                password.Password = "";
                Dashboard d2=new Dashboard();
                this.Close();
                d2.Show();

            }
            catch
            {

            }
        }
    }
}
