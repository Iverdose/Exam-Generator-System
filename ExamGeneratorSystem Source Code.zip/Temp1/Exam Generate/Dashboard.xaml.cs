﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for Dashboard.xaml
    /// </summary>
    public partial class Dashboard : Window
    {
        public Dashboard()
        {
            InitializeComponent();
        }


        private void buttond1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login a = new login();
            a.Show();
        }

        private void buttond2(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createacc b = new createacc();
            b.Show();
        }

        private void createexamclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createexam g = new createexam();
            g.Show();
        }

        private void uploadclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            upload d = new upload();
            d.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Dashboard g = new Dashboard();
            g.Show();
        }

        private void viewscoresclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            results g = new results();
            g.Show();
        }

        private void flashcard_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            flashcard f = new flashcard();
            f.Show();
        }
    }
}
