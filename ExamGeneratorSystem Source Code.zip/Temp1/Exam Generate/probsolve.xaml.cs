﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for probsolve.xaml
    /// </summary>
    public partial class probsolve : Window
    {
        int num1;
        int num2;
        char op;

        public probsolve()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            result.Text += btn.Content.ToString();
            num2 = Int32.Parse(result.Text);
        }

        private void divclick(object sender, RoutedEventArgs e)
        {
            num1 = Int32.Parse(result.Text);
            op = '/';
            result.Clear();

        }

        private void multipclick(object sender, RoutedEventArgs e)
        {
            num1 = Int32.Parse(result.Text);
            op = 'X';
            result.Clear();
        }

        private void subclick(object sender, RoutedEventArgs e)
        {
            num1 = Int32.Parse(result.Text);
            op = '-';
            result.Clear();
        }

        private void addclick(object sender, RoutedEventArgs e)
        {
            num1 = Int32.Parse(result.Text);
            op = '+';
            result.Clear();
        }

        private void equalsclick(object sender, RoutedEventArgs e)
        {
            num2 = Int32.Parse(result.Text);
            int res = 0;

            if(op == '/')
            {
                res = num1 / num2;
            }
            else if(op == '-')
            {
                res = num1 - num2;
            }
            else if (op == '*')
            {
                res = num1 * num2;
            }
            else if (op == '+')
            {
                res = num1 + num2;
            }
            if (result.Text == "0")
            {
                result.Clear();
            }
            result.Text = res.ToString();
        }

        private void buttond1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login f2 = new login();
            f2.Show();
        }

        private void buttond2(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createacc a = new createacc();
            a.Show();
        }

        private void TextBox_IsHitTestVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
          
        }

        private void createexamclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createexam n = new createexam();
            n.Show();
        }

        private void flashcard_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            flashcard f = new flashcard();
            f.Show();
        }
    }
}
