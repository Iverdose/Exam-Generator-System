﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for createexam.xaml
    /// </summary>
    public partial class createexam : Window
    {
        public createexam()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void buttond1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login f2 = new login();
            f2.Show();
        }

        private void buttond2(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createacc a = new createacc();
            a.Show();
        }

        private void psclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            probsolve f = new probsolve();
            f.Show();
        }

        private void idenclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            iden h = new iden();
            h.Show();
        }

        private void mcclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            mulchoice i = new mulchoice(); 
            i.Show();
        }

        private void viewscoresclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            results g = new results();
            g.Show();
        }

        private void flashcard_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            flashcard f = new flashcard();
            f.Show();
        }
    }
}
