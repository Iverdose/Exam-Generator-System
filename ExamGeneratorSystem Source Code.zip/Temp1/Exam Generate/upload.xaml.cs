﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for upload.xaml
    /// </summary>
    public partial class upload : Window
    {
        public upload()
        {
            InitializeComponent();
        }

        private void ulclick(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
            bool? response = openFileDialog.ShowDialog();

            if(response == true)
            {
                string filepath = openFileDialog.FileName;

                MessageBox.Show(filepath);
            }
        }

        private void buttond1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login f2 = new login();
            f2.Show();
        }

        private void buttond2(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createacc f2 = new createacc();
            f2.Show();
        }

        private void createexamclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createexam g = new createexam();
            g.Show();
        }

        private void viewscoresclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            results g = new results();
            g.Show();
        }

        private void flashcard_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            flashcard f = new flashcard();
            f.Show();
        }
    }
}
