﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for login.xaml
    /// </summary>
    public partial class login : Window
    {
        public login()
        {
            InitializeComponent();
        }

        private void button(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createacc a = new createacc();
            a.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void login_click(object sender, RoutedEventArgs e)
        {
            Dashboard d2 = new Dashboard();
            d2.Show();
            this.Close();
            SqlConnection sqlCon = new SqlConnection(@"Data Source=localhost\sqle2019;Initial Catalog=ExamGenerator_DB;Integrated Security=True");
            try
            {
                if (sqlCon.State == System.Data.ConnectionState.Closed)
                    sqlCon.Open();
                string query = "SELECT COUNT(1) FROM StudentTB WHERE username=@StudentName AND password=@StudentPassword";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.CommandType = System.Data.CommandType.Text;
                sqlCmd.Parameters.AddWithValue("@StudentName", username.Text);
                sqlCmd.Parameters.AddWithValue("@StudentPassword", password.Password);
                int count = Convert.ToInt32(sqlCmd.ExecuteScalar());
                if (count == 1)
                {
                    Dashboard d1 = new Dashboard();
                    d1.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Username or password is incorrect.");

                }
            }
            catch
            {

            }

        }
    }
}
