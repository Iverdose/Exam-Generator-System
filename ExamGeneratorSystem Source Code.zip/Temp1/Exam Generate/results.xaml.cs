﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exam_Generate
{
    /// <summary>
    /// Interaction logic for results.xaml
    /// </summary>
    public partial class results : Window
    {
        public results()
        {
            InitializeComponent();
        }

        private void buttond1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login g = new login();
            g.Show();
        }

        private void buttond2(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createacc g = new createacc();
            g.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Dashboard g = new Dashboard();
            g.Show();
        }

        private void uploadclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            upload g = new upload();
            g.Show();
        }

        private void createexamclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            createexam g = new createexam();
            g.Show();
        }

        private void viewscoreclick(object sender, RoutedEventArgs e)
        {
            this.Hide();
            results g = new results();
            g.Show();
        }

        private void flashcard_click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            flashcard f = new flashcard();
            f.Show();
        }
    }
}
